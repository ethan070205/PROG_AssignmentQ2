/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Prog_AssignmentQ2;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author User
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
       static ArrayList<String> defenders = new ArrayList<>();
       static ArrayList<Integer> tackles = new ArrayList<>();
       static ArrayList<Integer> goals = new ArrayList<>();
       static ArrayList<Integer> defGames = new ArrayList<>();
       static ArrayList<Integer> stGames = new ArrayList<>();
       static ArrayList<Double> defPay = new ArrayList<>();
       static ArrayList<Double> stPay = new ArrayList<>();
       static ArrayList<String> strikers = new ArrayList<>();
       
       public static int userInput = 0;
       public static int count = 0;
       public static String name;
       public static String choice;

    public static ArrayList<String> getDefenders() {
        return defenders;
    }

    public static void setDefenders(ArrayList<String> defenders) {
        Question2.defenders = defenders;
    }

    public static ArrayList<Integer> getTackles() {
        return tackles;
    }

    public static void setTackles(ArrayList<Integer> tackles) {
        Question2.tackles = tackles;
    }

    public static ArrayList<Integer> getGoals() {
        return goals;
    }

    public static void setGoals(ArrayList<Integer> goals) {
        Question2.goals = goals;
    }

    public static ArrayList<Integer> getDefGames() {
        return defGames;
    }

    public static void setDefGames(ArrayList<Integer> defGames) {
        Question2.defGames = defGames;
    }

    public static ArrayList<Integer> getStGames() {
        return stGames;
    }

    public static void setStGames(ArrayList<Integer> stGames) {
        Question2.stGames = stGames;
    }

    public static ArrayList<Double> getDefPay() {
        return defPay;
    }

    public static void setDefPay(ArrayList<Double> defPay) {
        Question2.defPay = defPay;
    }

    public static ArrayList<Double> getStPay() {
        return stPay;
    }

    public static void setStPay(ArrayList<Double> stPay) {
        Question2.stPay = stPay;
    }

    public static ArrayList<String> getStrikers() {
        return strikers;
    }

    public static void setStrikers(ArrayList<String> strikers) {
        Question2.strikers = strikers;
    }

    public int getUserInput() {
        return userInput;
    }

    public void setUserInput(int userInput) {
        this.userInput = userInput;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }
       
       
    public static void main(String[] args) 
            
    {
      Enter();
      Output();
        
    }
    
    
    
    public static void Enter(){
        int goalsScored;
        Scanner kb = new Scanner(System.in);
        
        
        System.out.println("How many players are there?");
        userInput = kb.nextInt();
      
      for (int i = 0; i < userInput; i++) 
     {
        System.out.println("is the player a Striker of defender?");
        choice = kb.next();
        System.out.println("what is the players name?");
        name = kb.next();
          
          
          Player pl = new Player(name,Player.getGamesPlayed());
        if (choice.contains("s")) 
        {
            strikers.add(name);
            Striker st = new Striker(Player.getName(), Striker.getGoalsScored(), Player.getGamesPlayed());
           
           
           
            
        }  
        else if (choice.contains("d")) 
         {
            defenders.add(name);
            Defender df = new Defender(Player.getName(), Player.getGamesPlayed(),
                    Defender.getTacklesMade());
            
         
           
         }
     }
    
    }
    
        public static void Output(){
         System.out.println("-------------------------");
         System.out.println("---------PLAYERS---------");
         System.out.println("-------------------------\n");
         if (strikers.isEmpty()) 
        {
             System.out.println("There are no strikers.");
        }
         else
         {
         System.out.print("STRIKERS -\n"
                 + "Name:           " + strikers);
         System.out.print("\nGames played:     " + stGames);
         System.out.print("\nGoals Scored:     " + goals);
         System.out.println("\nPAY:        R" + stPay);
         System.out.println("\n--------------------------\n");
         }
         if (defenders.isEmpty()) 
        {
             System.out.println("There are no defenders.");
        }
         else
         {
         System.out.print("DEFENDERS -\n"
                 + "Name:          " + defenders);
         System.out.print("\nGames played:   " + defGames);
         System.out.print("\nTackles made:   " + tackles);
         System.out.println("\nPAY:        R" + defPay);
         }
           
        }
    }
    