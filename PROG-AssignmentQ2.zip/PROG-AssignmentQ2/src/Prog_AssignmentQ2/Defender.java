/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prog_AssignmentQ2;

import static Prog_AssignmentQ2.Question2.defGames;
import static Prog_AssignmentQ2.Question2.defPay;
import static Prog_AssignmentQ2.Question2.stPay;
import static Prog_AssignmentQ2.Question2.tackles;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Defender extends Player 
{
  private static int tacklesMade;
  private static int gamesPlayed;
  public static double pay;
   Scanner kb = new Scanner (System.in);
  public Defender(String name, int gamesPlayed, int tacklesMade)
  {
     
        super(name, gamesPlayed);
        this.tacklesMade = tacklesMade;
        this.gamesPlayed = gamesPlayed;
        System.out.println("how many tackles did the defender make?");
        tacklesMade = kb.nextInt();
         tackles.add(tacklesMade);
        System.out.println("how many games did the defender play in?");
        gamesPlayed = kb.nextInt();
         defGames.add(gamesPlayed);
         pay = (gamesPlayed*1000) + (tacklesMade*500);
         defPay.add(pay);
        Defender.calculatePay();
        
  }

    public static void setTacklesMade(int tacklesMade) {
        Defender.tacklesMade = tacklesMade;
    }

    public static void setGamesPlayed(int gamesPlayed) {
        Defender.gamesPlayed = gamesPlayed;
    }

    public static void setPay(double pay) {
        Defender.pay = pay;
    }

    public static int getTacklesMade() {
        return tacklesMade;
    }

    
    public static int getgamesPlayed() {
        return gamesPlayed;
    }

  
    public static double calculatePay()
{
    
     pay = (gamesPlayed*1000) + (tacklesMade*500);

    return pay;
}
  
  
} 
   


