/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prog_AssignmentQ2;

import static Prog_AssignmentQ2.Defender.calculatePay;
import static Prog_AssignmentQ2.Question2.goals;
import static Prog_AssignmentQ2.Question2.stGames;
import static Prog_AssignmentQ2.Question2.stPay;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Striker extends Player
{
  private static int goalsScored;
  private static int gamesPlayed;
  public static double pay;
  Scanner kb = new Scanner (System.in);
  
  public Striker(String name, int goalsScored, int gamesPlayed)
  {      

     
        super(name, gamesPlayed);
        this.goalsScored = goalsScored = 0;
        this.gamesPlayed = gamesPlayed = 0;
        System.out.println("how many goals did the striker score?");
        goalsScored = kb.nextInt();
         goals.add(goalsScored);
        System.out.println("how many games did the striker play in?");
        gamesPlayed = kb.nextInt();
        stGames.add(gamesPlayed);
        pay = (gamesPlayed*1000) + (goalsScored*1500);
        stPay.add(pay);
        Striker.calculatePay();
        
  }

    public static int getGoalsScored() {
        return goalsScored;
    }

   
    public static int getgamesPlayed() {
        return gamesPlayed;
    }

   
    public static double calculatePay()
{ 
     
     pay = (gamesPlayed*1000) + (goalsScored*1500);
   
     return pay;
}

    public static void setGoalsScored(int goalsScored) {
        Striker.goalsScored = goalsScored;
    }

    public static void setGamesPlayed(int gamesPlayed) {
        Striker.gamesPlayed = gamesPlayed;
    }

    public static void setPay(double pay) {
        Striker.pay = pay;
    }

    
  
}