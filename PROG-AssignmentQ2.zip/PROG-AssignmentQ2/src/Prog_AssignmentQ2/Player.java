/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prog_AssignmentQ2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Player 
{
    public static int games_played;
    private static String name;
    
   
     ArrayList<String> Name = new ArrayList<>();
    
     public Player(String name, int gamesPlayed)
  {
      Scanner kb = new Scanner (System.in);
      this.name = name;
       this.games_played = games_played;
       
  }  
  
  
  public static String getName()
  {
      return name;
  }
  public static int getGamesPlayed()
  {return games_played;}
  
     public static double calculatePay()
   {
    return 0;
   }
}
