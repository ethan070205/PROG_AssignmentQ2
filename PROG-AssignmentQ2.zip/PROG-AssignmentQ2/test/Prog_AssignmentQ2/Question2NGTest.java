/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Prog_AssignmentQ2;

import java.io.ByteArrayInputStream;
import static org.testng.Assert.*;
import org.testng.annotations.Test;


/**
 *
 * @author User
 */
public class Question2NGTest {
    
    public Question2NGTest() {
    }

    @Test
    public void testOutput() 
    {
        System.out.println("OUTPUT");
       Question2 Q2 = new Question2();
       Question2.Output();
    }
    
    @Test
    public void testEnterStriker()
    {
        Question2 Q2 = new Question2();
        Q2.setChoice("striker");
        Q2.setName("Ethan");
        Q2.setUserInput(1);
        
        assertEquals("striker", Q2.getChoice());
        assertEquals("Ethan", Q2.getName());
        assertEquals(1, Q2.getUserInput());
    }
    
    @Test
    public void testEnterDefender()
    {
        Question2 Q2 = new Question2();
        Q2.setChoice("defender");
        Q2.setName("Sena");
        Q2.setUserInput(1);
        
        assertEquals("defender", Q2.getChoice());
        assertEquals("Sena", Q2.getName());
        assertEquals(1, Q2.getUserInput());
    }
    
    
    @Test
    public void testCalculatePay_Striker()
    {
        Striker.setGoalsScored(6);
        Striker.setGamesPlayed(7);
        Question2 Q2 = new Question2();        
        int pay = (Striker.getGamesPlayed()*1000) + (Striker.getGoalsScored()*1500);
         System.out.println(pay);
    }
    
    @Test
    public void testCalculatePay_Defender()
    {
         Question2 Q2 = new Question2();  
         Defender.setGamesPlayed(6);
         Defender.setTacklesMade(12);
         int pay = (Defender.getGamesPlayed()*1000) + (Defender.getTacklesMade()*500);
         System.out.println(pay);
    }
}
